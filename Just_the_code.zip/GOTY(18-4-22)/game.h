#ifndef GAME_H
#define GAME_H


class game
{
public:
    game();
};

#endif // GAME_H
